# Stock Catalyst Discovery — additive offline acceptance package

**Date:** November 1, 2026  
**Status:** DEVELOPMENT ONLY — no deployment, no network collector, no production alerts, no database writes.  
**Mission:** government + independent news + broad U.S. market activity -> shared durable evidence and research -> existing iPhone alerts. Unchanged.

This package is additive. It does **not** replace or assume access to the previous `src/issuer_candidates.js`, `src/market_budget_audit.js`, or the earlier reported 135-test package. Nothing here has been committed to the user's existing GitHub repository or added to Supabase.

## Run

Node.js 22+:

```sh
node --test test/*.test.mjs
```

In the isolated environment used for this package: **64 tests passed; 0 failed** after debugging. The earlier historical **135 tests passed** figure has **not** been independently rerun or added to this count. The actual original source package must be obtained before compatibility, integration, and regression testing.

## `src/issuer_primary_sources.mjs`

- Parses the official SEC `company_tickers_exchange.json` columnar data format: CIK, SEC conformed name, ticker, exchange.
- Parses individual SEC submissions metadata with current ticker/exchange arrays and separately records former names.
- Parses Nasdaq Trader `nasdaqlisted.txt` and `otherlisted.txt` directory snapshots including their original Eastern file creation stamp.
- Preserves source URL, capture time, source-file time where available, SHA-256 raw-byte fingerprint, original legal/security names and quarantine evidence.
- Stops an incomplete or stale directory/SEC snapshot from being treated as cross-correlated.
- Requires agreement across SEC exchange data, SEC company submissions and an independent exchange directory before producing **primary_source_cross_correlated** (still NOT final verification).
- Flags alias collisions, duplicate CIK/ticker rows, share classes, ticker reuse possibilities, source disagreement and uncertain company/parent relationships.
- Does not infer subsidiaries, ownership or completed acquisitions from a name, filing URL or an announcement.

**Important custody limitation:** The adapter computes fingerprints and returns metadata but is not a persistent raw-source archive. The caller must store the original bytes separately in a durable, immutable, verified archive before advancing checkpoints.

**Important SEC limitation:** The SEC states its ticker/CIK/exchange association files are periodically updated but their accuracy and scope are not guaranteed. Capture time is not a publisher effective date. Even cross-correlated matches require independent investigation for active trading, issuer/parent ownership and unusual-catalyst qualification.

**Important fixture limitation:** The example company names in `/fixtures` are synthetic. These tests validate parsing and failure policy, not real issuer identification. A documented bounded official SEC data snapshot is the next integration fixture, subject to SEC fair-access rules.

## `src/us_equity_session_calendar.mjs`

- Source-bounded Nasdaq U.S. equities **2026** holiday and early-close calendar.
- Converts UTC timestamps to America/New_York without a hardcoded UTC offset; tested around spring/fall DST transitions.
- Separates 4:00–9:30 a.m. ET premarket, 9:30 a.m.–4:00 p.m. regular and 4:00–8:00 p.m. postmarket on ordinary trading dates.
- Handles official Nov 27 and Dec 24 2026 **1 p.m. ET** early closes, with post-close extended hours flagged **unverified**.
- Marks years outside 2026 `calendar_unverified`, never assumes holiday rules.
- Counts missing/duplicate/unclassified one-minute scheduled observations separately from actual security-level market-data coverage.
- Does not assume 2026 Nasdaq proposed 9 p.m.–4 a.m. Global Trading Hours are already operating or available in Tickerbot.
- 22 hypothetical full 16-hour days at 1 call/minute require 21,120 calls **before pagination and retries**; not evidence of real market-wide completeness.

**Coverage warning:** These are a documented Nasdaq baseline and explicit unknown windows. They do not claim that every market venue, OTC market, alternate trading system, or vendor scan follows identical hours; an actual Tickerbot availability and quota audit remains required.

## Official technical sources inspected November 1, 2026

- SEC CIK/ticker/exchange associations and accuracy disclaimer: https://www.sec.gov/search-filings/edgar-search-assistance/accessing-edgar-data
- SEC source JSON structure: https://www.sec.gov/files/company_tickers_exchange.json
- SEC submissions metadata: https://www.sec.gov/search-filings/edgar-application-programming-interfaces
- Nasdaq Trader directory field definitions: https://www.nasdaqtrader.com/Trader.aspx?id=SymbolDirDefs
- Nasdaq 2026 holidays, early closes, extended-day sessions: https://www.nasdaq.com/market-activity/stock-market-holiday-schedule
- NYSE calendar cross-reference: https://www.nyse.com/trade/hours-calendars
- Nasdaq Global Trading Hours forward-looking clarification: https://www.nasdaq.com/docs/nasdaq-global-trading-hours-faqs

## Limitations and next verification

1. Retrieve full original November 1 source package to ensure no duplicate module semantics and rerun historical tests; no existing source code was overwritten.
2. Capture SEC and Nasdaq original response bytes compliantly with metadata and rate-limited retrieval. A full snapshot must be demonstrably complete before a checkpoint may be advanced.
3. Add explicit exchange directory reconciliation for missing and inconsistent symbol data; test ticker changes and real SEC filing-based parent/merger evidence.
4. Integrate with existing evidence/research-queue schema only after compatibility review.
5. Test actual schedule and market-data coverage using real Tickerbot request timestamps and pagination accounting, without exceeding free quotas.
6. Resolve existing GitHub Actions Supabase session-pooler secret through the user's secure GitHub secret settings. Do not paste secrets into chat or commit them. The pre-existing manual LuxAlgo workflow should be reused, not duplicated.
7. Separate independent offsite backups, Supabase Free inactivity recovery, two-worker queue concurrency and authorized notification acceptance remain open.

No deployment, paid operation, automation, notification, database schema, source-code commit, or trade was executed by this package.

## `src/append_only_evidence_ledger.mjs` (offline prototype)

Append/replay codec for a tamper-evident ordered JSONL evidence trail. A SHA-256 hash chain detects accidental modifications, reordering and incomplete final lines; it does not provide authenticated signatures or prevent an adversary from replacing the entire file. The caller must implement atomic durable writes, locking, checkpoints, independent raw-byte archives and offsite backups. All tests use synthetic records; this is **not** integrated with production Supabase or the existing research queue.

## November 1 additional verification

Scan coverage auditing now distinguishes missing pages from failed pages and detects duplicate instrument rows. Full isolated offline suite: **89 passed, 0 failed**. Read-only Supabase constraint inspection documented in `docs/POSTGRES_CONCURRENCY_REVIEW_2026-11-01.md`. Real two-worker PostgreSQL concurrency, actual exchange completeness, live notification delivery and independent backup restoration remain untested.

### Transaction reference model (November 1)
`src/transaction_acceptance_model.mjs` provides an **offline-only** model of atomic event/revision/outbox/checkpoint commit and fault injection. It is not a database adapter, not a lock implementation, and must not be deployed as a replacement for PostgreSQL transactions. Run `node --test test/*.test.mjs`. Real two-session concurrency and native LuxAlgo acceptance remain blocked pending the secure PostgreSQL connection in GitHub Actions.

### New: source checkpoint recovery gate
`src/source_recovery_gate.mjs` exposes `decideCheckpoint` for an offline, fail-closed preflight on coverage, quarantines, durable transaction receipts, outbox and checkpoint atomicity. Its receipt input is supplied by the caller and **must not be treated as independently verified**. A real database transaction and authenticated receipt source are required before using this for production checkpoint decisions. See the 15 new tests in `test/source_recovery_gate.test.mjs`.

### Follow-up review — fail-closed coverage shape
Review of the Version 7 gate found that omitted or malformed `unsuccessful_pages`, `missing_pages`, or `issues` fields could pass the coverage checks when the other synthetic fields claimed completeness. The gate now rejects absent or non-array page-status fields as `coverage_shape_unverified`; six regression tests cover each field in both cases. Current full offline suite: **122 passed, 0 failed**. This remains a synthetic preflight model, not a live source or database guarantee.
