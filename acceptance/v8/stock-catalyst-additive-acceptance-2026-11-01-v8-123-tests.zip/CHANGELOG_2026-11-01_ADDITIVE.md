# Additive change log — November 1, 2026

## 2026-11-01 — Read-only continuation verification
- Existing repository `Mmundo74/stock-catalyst-discovery` read via connected GitHub; manual `workflow_dispatch` LuxAlgo workflow and native test harness retrieved and inspected.
- Existing Supabase project `yeojyalevdljuddehukn` verified `ACTIVE_HEALTHY`; both `catalyst_acceptance` and `catalyst_acceptance_restore` private acceptance schemas found with six expected tables apiece via read-only SQL.
- Available project file search found the October 24 handoff; latest 135-test executable source package not found. The historic 135/0 result is preserved as a reported previous result, not new independently verified test evidence.
- No changes made to live infrastructure.

## 2026-11-01 — Independent issuer/CIK/source-correlation prototype
- Existing design: `src/issuer_candidates.js` reportedly offline-tested in earlier package, not accessible for comparison.
- Proposed additive component: `src/issuer_primary_sources.mjs` as source-backed fixture parser and correlation gate.
- Rationale: distinguish authoritative source assertions from unchecked name matches, ambiguous legal identities, and unverified parent relationships.
- Sources: published SEC and Nasdaq field definitions.
- Cost: zero external paid-service calls in tests; no live SEC/Nasdaq retrievals by generated code.
- Security and recovery: source hashes, quarantine, conservative results; durable raw archiving not implemented.
- Preserved: original issuer adapter, all three discovery engines, LuxAlgo, GitHub workflows, Supabase schemas and notification pipeline.
- Verification: standalone Node 22 test suite passed (64 tests total across both new modules). Initial 35 issuer tests had 2 mistaken expectations for ambiguous names; corrected, then added strict disagreement and DST checks and reran. Subsequent specific CIK-only class ambiguity issue corrected and retested.
- Authorization: offline independent build and testing under project's continuation instruction; no production deployment or repository mutation.

## 2026-11-01 — Independent 2026 market calendar/coverage prototype
- Existing design: `src/market_budget_audit.js` reportedly offline-tested, not accessible to compare.
- Proposed additive component: `src/us_equity_session_calendar.mjs` for Nasdaq 2026 supported session windows and minute-level observability accounting.
- Rationale: holidays, half-days, DST and unverified extended windows should not silently disappear from coverage accounting.
- Cost: no API calls from generated code; no schedules activated.
- Security/recovery: explicitly identifies unverified years/early-close extended windows and missed minute scans; not sufficient for ticker-level coverage or outage recovery.
- Preserved: original market adapter and 135 historical tests, all cloud and alert infrastructure.
- Verification: calendar unit tests passed; one initial test used an uppercase text assertion where limitations text was lowercase. Test assertion corrected and retested, with no calendar logic change required for that failure.
- Authorization: standalone local test-only development, no service activation or material architecture replacement.

## Outstanding blockers
- Full original 135-test source package not accessible in the present runtime.
- GitHub Actions `SUPABASE_SESSION_POOLER_URL` secret configuration not independently verified; native LuxAlgo hosted workflow not run in this continuation.
- Offsite backup, Supabase pauses, complete free market coverage, live issuer evidence, multiworker queue, AI unattended research, and end-to-end alert duplication/delivery remain unverified.
- Public GitHub commit-email privacy concern remains unchanged.

## November 1, 2026 — continued offline development
- Added `src/scan_coverage_ledger.mjs` and `test/scan_coverage_ledger.test.mjs` as an additive, offline-only market scan coverage audit.
- Existing design: session calendar and quota estimator; new module: page, instrument, NULL signal and stale price accounting.
- Reason: prevent a successful scan response or nominal instrument count from being misrepresented as complete signal coverage.
- Preserved: all three discovery engines, existing LuxAlgo/Tickerbot/Make/Supabase/GitHub systems, previous 64 tests, original 135-test historical evidence.
- Tests: 74 passed, 0 failed (64 original package tests + 10 new). No live provider or database test.
- Cost: zero API calls and zero hosted jobs. Security/recovery: no credentials, no persistent checkpoint writes; the module always marks checkpoint eligibility false pending downstream evidence policy.
- Authorization: user authorized continued isolated development; no production change requested or performed.

### Continued development — append-only evidence chain (2026-11-01)
- Added `src/append_only_evidence_ledger.mjs` and 10 synthetic offline tests.
- Hash-linked, ordered JSONL records; detects truncation, mutation, reordering, duplicate IDs and invalid event timestamps.
- Test suite: 84 passed, 0 failed. This codec does **not** itself implement durable fsync, database transactions, raw-source custody, two-worker locking, offsite backups or production integration.
- Additive only: replaces nothing, preserves existing collectors and pipelines, no production activation or external calls. User's standing authorization permits isolated development/testing; no deployment authorization inferred.

### PostgreSQL integration review (additional)
- Inspected existing `catalyst_acceptance` table columns through connected Supabase, read-only.
- Added `docs/POSTGRES_CONCURRENCY_REVIEW_2026-11-01.md` with concrete concurrency, checkpoint, notification, and backup acceptance cases.
- Preserved all existing tables and workflows. No live concurrency test or database mutation claimed.

### Additional acceptance hardening (November 1)
- Fixed offline scan accounting: failed pages now appear in `unsuccessful_pages`, distinct from missing page numbers; duplicate instrument rows, malformed rows and invalid request timestamps are explicitly handled.
- Added five regression tests. Latest full available suite: 89 passed, 0 failed.
- Inspected existing Supabase acceptance constraints read-only; documented actual primary/foreign key dependencies and transaction ordering. No database mutations or worker-concurrency claims.
- Replaces: only the isolated prototype `src/scan_coverage_ledger.mjs` implementation in this additive package; preserves original project source, live schema, collectors and notification workflows. User authorized continued offline development, not production deployment.

### November 1 — Additional isolated transaction reference tests (not deployed)
Added `src/transaction_acceptance_model.mjs` and `test/transaction_acceptance_model.test.mjs`. Ten new synthetic regression tests verify atomic batch simulation, duplicate replay, revision changes, outbox creation, injected failure rollback, checkpoint consistency, and orphan detection. Full additive suite: **99 passed, 0 failed** in this container. This is an in-memory model, **not** a real PostgreSQL transaction or concurrent-session test; it neither proves exactly-once external delivery nor replaces the native LuxAlgo harness. Existing repository, Supabase, workflows, collectors, and alert tasks untouched. No approval needed for isolated offline tests; no production changes authorized or made.

### November 1, 2026 — additive integrity fix (v6)
- Fixed a false orphan-revision alarm in the offline transaction acceptance model when a fingerprint contains a pipe delimiter. Revision records now carry explicit parentId instead of recovering the parent by splitting a compound key.
- Added two regression tests, including a missing-parent check. Full isolated suite rerun: **101 passed, 0 failed**.
- Preserves all three discovery engines and existing Supabase/GitHub infrastructure. No deployment, database mutation, or live two-session concurrency test. User authorized routine additive development; no mission change.

## Continuation — source checkpoint fail-closed preflight (2026-11-01)
- **Added:** `src/source_recovery_gate.mjs` and `test/source_recovery_gate.test.mjs`.
- **Why:** Prevent a coverage summary alone from being mistaken for authorization to advance a durable source cursor; require matching run/source durable commit receipt, same-transaction checkpoint evidence, outbox evidence, no quarantine, no page failures, and cursor progress.
- **Preserved:** All prior source files, all three independent engines, GitHub workflow, Supabase schemas, and alerts. No production activation or architectural replacement.
- **Tested:** Complete offline package 116 tests passed, zero failed (15 new checkpoint-gate tests compared with the last reported 101). Tests use synthetic receipts; cannot prove native PostgreSQL transactions or real source coverage.
- **Blocked:** Native LuxAlgo workflow requires secure Actions secret. GitHub integration previously rejected writes; this package is prepared as a local ZIP for Work ingestion. No database credential reset.

### Follow-up review — coverage-shape fail-closed fix (2026-11-01)
- **Found:** `decideCheckpoint` used optional chaining for page-status lists. If a purportedly complete coverage object omitted or malformed `unsuccessful_pages`, `missing_pages`, or `issues`, those checks could be skipped.
- **Changed:** Require all three fields to be arrays; missing or malformed fields now add `coverage_shape_unverified` and prevent checkpoint eligibility.
- **Tests:** Added six synthetic regressions (one missing and one malformed case per field). Full offline package rerun: **122 passed, 0 failed**.
- **Preserved:** All existing package modules and tests; no source collector, GitHub workflow, Supabase schema/data, Make scenario, notification task, or production setting changed.
- **Limitations:** Receipts are still caller-supplied assertions; offline tests do not establish real transaction durability, independent-session concurrency, source continuity, or alert delivery.
- **Authorization:** Additive offline code review/fix/testing is within the user's standing project authorization.

## 2026-11-01 — Follow-up offline validation
- Re-ran supplied Work-reviewed suite: 122/122 passed.
- Fixed acceptance reference model treating array-valued source payloads as valid JSON objects; arrays now fail validation before committing any model state.
- Added atomicity regression: invalid array payload leaves events, runs, and checkpoints unchanged.
- Re-ran full suite: 123 passed, 0 failed.
- Preserved all existing source modules and tests; no remote repository, database, schedule, or alert changes.
- This is a pure offline model fix, not live PostgreSQL acceptance.
