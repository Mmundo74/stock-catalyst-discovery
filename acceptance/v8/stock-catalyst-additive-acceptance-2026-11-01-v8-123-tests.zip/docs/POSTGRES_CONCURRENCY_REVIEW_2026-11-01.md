# PostgreSQL acceptance integration review — 2026-11-01

Status: schema inspected live, integration test NOT RUN. No database writes.

Existing acceptance schema has six tables: events, event_revisions, checkpoints, notification_outbox, pipeline_runs, source_health. Column shapes were read through the connected Supabase project yeojyalevdljuddehukn.

Required next acceptance test (isolated transactions and synthetic event IDs):
1. Inspect existing primary keys, unique constraints, foreign keys, indexes and RLS before any write.
2. Test two independent connections inserting the same (engine,source,source_event_id) concurrently. Verify one canonical event, immutable evidence revisions, and no silently lost payload conflicts.
3. Atomically insert event/revision/outbox and advance checkpoint only after the batch commits. Inject rollback and replay, then verify checkpoint and outbox consistency.
4. Test competing notification claims with FOR UPDATE SKIP LOCKED, worker crash/retry and idempotency, without sending real messages.
5. Restore from independent backup and reconcile row counts and hashes; a same-project schema copy is not offsite backup.

Blocking conditions: Connected execute_sql calls are individual statements, not guaranteed to be two independent persistent sessions. Thus they cannot prove simultaneous-worker concurrency. Use the prepared native Node.js GitHub Actions harness and securely configured connection secret, or another explicitly isolated multi-connection test runner. Never paste credentials into code or logs.

No claims of live concurrency or restore verification are made.

## Additional read-only constraint inspection — November 1

The existing live acceptance schema enforces composite canonical event identity `(engine,source,source_event_id)` on `events`. `event_revisions` has a composite `(engine,source,source_event_id,fingerprint)` primary key and a three-column foreign key to `events`. `notification_outbox` has an `idempotency_key` primary key and a four-column foreign key to `event_revisions`. `checkpoints.last_completed_run` references `pipeline_runs`. These are promising integrity guards, but **not** proof of transaction atomicity, safe concurrent workers, successful delivery idempotency, or exactly-once semantics.

Critical integration ordering: insert `pipeline_runs` before referencing it in `checkpoints`; insert `events` before `event_revisions`; insert `event_revisions` before `notification_outbox`; commit event, revision, outbox and checkpoint together. Test conflict payloads with distinct fingerprints, and never suppress evidence by blindly ignoring `ON CONFLICT`. Read-only inspection only; no SQL writes or live concurrent sessions occurred.
